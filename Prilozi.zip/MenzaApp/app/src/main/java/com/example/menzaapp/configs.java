package com.example.menzaapp;

public class configs {

    public static String[] names = {"Arh - Odeon", "Alu", "Borongaj", "Cvjetno", "Ekonomija", "Fer - Cassandra", "Ffzg", "Fsb", "Laščina SD",
    "Medicina", "Nsk", "Sava - Stjepan Radić", "Savska SC", "Šumarstvo", "Ttf", "Tvz", "Veterina"};
    public static String dinner = "Ručak - Večera";
    public static String lunch = "Ručak";
    public static int imgIds[] = {R.drawable.arh_canteen, R.drawable.alu_canteen, R.drawable.borongaj_canteen, R.drawable.cvjetno_canteen, R.drawable.ekonomija_canteen,
    R.drawable.fer_canteen, R.drawable.ffzg_canteen, R.drawable.fsb_canteen, R.drawable.lascina_canteen, R.drawable.med_canteen, R.drawable.nsk_canteen, R.drawable.sava_canteen,
    R.drawable.sc_canteen, R.drawable.sumarstvo_canteen, R.drawable.ttf_canteen, R.drawable.tvz_canteen, R.drawable.veterina_canteen};

}
